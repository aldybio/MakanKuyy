export interface Trivia {
    id: string;
    content: string;
    source: string;
}