import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awal',
  templateUrl: './awal.page.html',
  styleUrls: ['./awal.page.scss'],
})
export class AwalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
