import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgotpass2',
  templateUrl: './forgotpass2.page.html',
  styleUrls: ['./forgotpass2.page.scss'],
})
export class Forgotpass2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
