import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgotpass1',
  templateUrl: './forgotpass1.page.html',
  styleUrls: ['./forgotpass1.page.scss'],
})
export class Forgotpass1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
