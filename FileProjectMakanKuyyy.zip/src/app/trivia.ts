export class Trivia {
    key: string;
    content: string;
    source: string;

    constructor(
        key: string,
        content: string,
        source: string
    ){}
}
