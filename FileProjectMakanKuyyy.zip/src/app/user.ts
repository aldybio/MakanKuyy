export class User {
    user_id: string;
    names: string;
    emails: string;
    emailVerified: boolean;
    address: string;
    phones: string;
    niks: string;
    photo_profile: string;

    constructor(
    user_id: string,
    names: string,
    emails: string,
    emailVerified: boolean,
    address: string,
    phones: string,
    niks: string,
    photo_profile: string,
    ){}
}
