export class Menu {
    key: string;
    resto_key: string;
    menu_name: string;
    menu_desc: string;
    menu_price: string;
    menu_image: string;

    constructor(
        key: string,
        resto_key: string,
        menu_name: string,
        menu_desc: string,
        menu_price: string,
        menu_image: string
    ){}
}
