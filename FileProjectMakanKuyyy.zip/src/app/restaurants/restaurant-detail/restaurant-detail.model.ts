export interface Food {
    id_food: string;
    name: string;
    imageUrl: string;
    desc: string;
    harga: string;
}