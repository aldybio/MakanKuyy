export interface Restaurant {
    id: string;
    name: string;
    address: string;
    imageUrl: string;
    openHour: string;
}