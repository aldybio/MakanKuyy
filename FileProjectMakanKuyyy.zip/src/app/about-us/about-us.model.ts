export interface Aboutus {
    url: string;
    nama: string;
    nim: string;
}