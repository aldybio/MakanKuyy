(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["about-us-about-us-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/about-us/about-us.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/about-us/about-us.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>About Us</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\" size-md=\"6\" *ngFor=\"let a of about\">\n          <ion-card style=\"text-align: center;\">\n            <ion-card-header>\n              <ion-avatar style=\"block-size: 120px; width:120px; margin: auto;\">\n                <ion-img [src]=\"a.url\"></ion-img>\n              </ion-avatar>\n            </ion-card-header>\n            <ion-card-content>\n              <ion-card-title>\n                {{a.nama}}<br>{{a.nim}}\n              </ion-card-title>\n            </ion-card-content>\n          </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/about-us/about-us-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/about-us/about-us-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: AboutUsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsPageRoutingModule", function() { return AboutUsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _about_us_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./about-us.page */ "./src/app/about-us/about-us.page.ts");




const routes = [
    {
        path: '',
        component: _about_us_page__WEBPACK_IMPORTED_MODULE_3__["AboutUsPage"]
    }
];
let AboutUsPageRoutingModule = class AboutUsPageRoutingModule {
};
AboutUsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AboutUsPageRoutingModule);



/***/ }),

/***/ "./src/app/about-us/about-us.module.ts":
/*!*********************************************!*\
  !*** ./src/app/about-us/about-us.module.ts ***!
  \*********************************************/
/*! exports provided: AboutUsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsPageModule", function() { return AboutUsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _about_us_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./about-us-routing.module */ "./src/app/about-us/about-us-routing.module.ts");
/* harmony import */ var _about_us_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./about-us.page */ "./src/app/about-us/about-us.page.ts");







let AboutUsPageModule = class AboutUsPageModule {
};
AboutUsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _about_us_routing_module__WEBPACK_IMPORTED_MODULE_5__["AboutUsPageRoutingModule"]
        ],
        declarations: [_about_us_page__WEBPACK_IMPORTED_MODULE_6__["AboutUsPage"]]
    })
], AboutUsPageModule);



/***/ }),

/***/ "./src/app/about-us/about-us.page.scss":
/*!*********************************************!*\
  !*** ./src/app/about-us/about-us.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Fib3V0LXVzL2Fib3V0LXVzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/about-us/about-us.page.ts":
/*!*******************************************!*\
  !*** ./src/app/about-us/about-us.page.ts ***!
  \*******************************************/
/*! exports provided: AboutUsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsPage", function() { return AboutUsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _about_us_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./about-us.service */ "./src/app/about-us/about-us.service.ts");



let AboutUsPage = class AboutUsPage {
    constructor(aboutusService) {
        this.aboutusService = aboutusService;
    }
    ngOnInit() {
        this.about = this.aboutusService.getAllAboutus();
    }
};
AboutUsPage.ctorParameters = () => [
    { type: _about_us_service__WEBPACK_IMPORTED_MODULE_2__["AboutUsService"] }
];
AboutUsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-about-us',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./about-us.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/about-us/about-us.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./about-us.page.scss */ "./src/app/about-us/about-us.page.scss")).default]
    })
], AboutUsPage);



/***/ }),

/***/ "./src/app/about-us/about-us.service.ts":
/*!**********************************************!*\
  !*** ./src/app/about-us/about-us.service.ts ***!
  \**********************************************/
/*! exports provided: AboutUsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsService", function() { return AboutUsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let AboutUsService = class AboutUsService {
    constructor() {
        this.aboutus = [
            {
                url: 'https://instagram.fdps5-1.fna.fbcdn.net/v/t51.2885-15/sh0.08/e35/s640x640/22580297_269218003599599_2183509412772052992_n.jpg?_nc_ht=instagram.fdps5-1.fna.fbcdn.net&_nc_cat=111&_nc_ohc=apn9VS1v7KgAX8kZi7X&tp=1&oh=8e492705486481d996ae907483cdd766&oe=6006FB4E',
                nama: 'Arnoldus Bio Dhae',
                nim: '00000023759'
            },
            {
                url: 'https://instagram.fcgk27-1.fna.fbcdn.net/v/t51.2885-19/s150x150/117610163_3011333012311027_4762675807962004776_n.jpg?_nc_ht=instagram.fcgk27-1.fna.fbcdn.net&_nc_cat=107&_nc_ohc=6fwy56y4v50AX-vy6GR&tp=1&oh=9ad52d395abe57e0526f162236dd0b51&oe=60043DE0',
                nama: 'Edward Louis Rago',
                nim: '00000022464'
            },
            {
                url: 'https://instagram.fdps5-1.fna.fbcdn.net/v/t51.2885-15/sh0.08/e35/s640x640/60405642_604214063416135_1916129783150024487_n.jpg?_nc_ht=instagram.fdps5-1.fna.fbcdn.net&_nc_cat=107&_nc_ohc=4UZAtElYvp4AX889X9I&tp=1&oh=b9ac9b7af84bee3e0b302132675344cf&oe=60034C29',
                nama: 'Vincent Tjeng Tjendra',
                nim: '00000022700'
            },
            {
                url: 'https://instagram.fdps5-1.fna.fbcdn.net/v/t51.2885-15/sh0.08/e35/s640x640/67423489_355684888700629_6503070153677891771_n.jpg?_nc_ht=instagram.fdps5-1.fna.fbcdn.net&_nc_cat=101&_nc_ohc=V-jv6YIW7jcAX_YylKO&tp=1&oh=b576f3d734a467838fdbd1fe5dc75755&oe=60038472',
                nama: 'Charles Matheus Rianaldo',
                nim: '00000022805'
            },
            {
                url: 'https://instagram.fdps5-1.fna.fbcdn.net/v/t51.2885-15/sh0.08/e35/p640x640/21909183_274981463006376_2512602988246204416_n.jpg?_nc_ht=instagram.fdps5-1.fna.fbcdn.net&_nc_cat=100&_nc_ohc=ysMtB_tkzkYAX88mh_O&tp=1&oh=7bc9f75bd2b42f1a8e64e4548f3fbffe&oe=6006F97A',
                nama: 'Yoshua',
                nim: '00000020472'
            }
        ];
    }
    getAllAboutus() {
        return [...this.aboutus];
    }
    getAbout(nim) {
        return Object.assign({}, this.aboutus.find(person => {
            return person.nim === nim;
        }));
    }
};
AboutUsService.ctorParameters = () => [];
AboutUsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AboutUsService);



/***/ })

}]);
//# sourceMappingURL=about-us-about-us-module-es2015.js.map