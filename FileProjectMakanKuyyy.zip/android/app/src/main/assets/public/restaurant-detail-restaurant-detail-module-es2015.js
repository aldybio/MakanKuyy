(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["restaurant-detail-restaurant-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/restaurants/restaurant-detail/restaurant-detail.page.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/restaurants/restaurant-detail/restaurant-detail.page.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{resto_name}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"primary\">\n  <ion-card style=\"width: 100%; margin: auto;\">\n    <ion-list color=\"primary\">\n      <ion-row color=\"primary\">\n        <ion-col color=\"primary\">\n          <ion-item color=\"primary\">\n          <ion-avatar style=\"block-size: 150px; width:150px;\" color=\"primary\">\n            <ion-img [src]=\"resto_image\"></ion-img>\n          </ion-avatar>\n          <ion-label style=\"margin-left: 2%;\" color=\"secondary\">\n            {{resto_name}}<br>{{resto_hour_open}} - {{resto_hour_close}}<br>\n            <small>{{resto_address}}, {{resto_city}}</small><br>\n            <!-- <ion-icon color=\"tertiary\" name=\"document-text-outline\"></ion-icon>\n            <ion-icon color=\"danger\" name=\"close-circle-outline\"></ion-icon> -->\n            <div style=\"width: 75%; border-radius: 10px; background-color: #002c49; text-align: center; padding: 5px; margin: 10px auto 0\" color=\"secondary\">\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n            </div>\n            <br><br><br>\n          </ion-label>\n        </ion-item>\n        </ion-col>\n      </ion-row>\n      \n      <!-- <ion-row>\n        <ion-col>\n          <ion-item color=\"warning\"><h1>{{loadedRestaurant.name}} </h1></ion-item>\n        </ion-col>\n      </ion-row> -->\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-list color=\"secondary\" class=\"detail-recipe\">\n              <!-- <ion-item color=\"medium\" *ngFor=\"let food of foods\">\n                <ion-avatar slot=\"start\" style=\"block-size: 90px; width:90px; margin-top: 2%; margin-bottom: 2%;\">\n                  <ion-img [src]=\"food.imageUrl\"></ion-img>\n                </ion-avatar>\n                <ion-label style=\"margin-left: 2%;\">\n                  {{food.name}}<br>\n                  Desc : {{food.desc}}<br>\n                  Harga : {{food.harga}}\n                </ion-label>\n              </ion-item> -->\n\n              <ion-item color=\"secondary\" *ngFor=\"let food of foods\">\n                <ion-avatar class=\"avatar-food\" slot=\"start\" style=\"block-size: 90px; width:90px; margin: 2% 0;\">\n                  <ion-img [src]=\"food.imageUrl\"></ion-img>\n                </ion-avatar>\n                <ion-label style=\"margin-left: 2%;\">\n                  <p>{{food.name}}</p>\n                  <small>{{food.desc}}</small>\n                  <p>Harga : {{food.harga}}</p>\n                </ion-label>\n              </ion-item>\n\n            </ion-list>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </ion-list>\n  </ion-card>\n</ion-content>");

/***/ }),

/***/ "./src/app/restaurants/restaurant-detail/restaurant-detail-routing.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/restaurants/restaurant-detail/restaurant-detail-routing.module.ts ***!
  \***********************************************************************************/
/*! exports provided: RestaurantDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestaurantDetailPageRoutingModule", function() { return RestaurantDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _restaurant_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./restaurant-detail.page */ "./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts");




const routes = [
    {
        path: '',
        component: _restaurant_detail_page__WEBPACK_IMPORTED_MODULE_3__["RestaurantDetailPage"]
    }
];
let RestaurantDetailPageRoutingModule = class RestaurantDetailPageRoutingModule {
};
RestaurantDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RestaurantDetailPageRoutingModule);



/***/ }),

/***/ "./src/app/restaurants/restaurant-detail/restaurant-detail.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.module.ts ***!
  \***************************************************************************/
/*! exports provided: RestaurantDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestaurantDetailPageModule", function() { return RestaurantDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _restaurant_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./restaurant-detail-routing.module */ "./src/app/restaurants/restaurant-detail/restaurant-detail-routing.module.ts");
/* harmony import */ var _restaurant_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./restaurant-detail.page */ "./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts");







let RestaurantDetailPageModule = class RestaurantDetailPageModule {
};
RestaurantDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _restaurant_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["RestaurantDetailPageRoutingModule"]
        ],
        declarations: [_restaurant_detail_page__WEBPACK_IMPORTED_MODULE_6__["RestaurantDetailPage"]]
    })
], RestaurantDetailPageModule);



/***/ }),

/***/ "./src/app/restaurants/restaurant-detail/restaurant-detail.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.page.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Jlc3RhdXJhbnRzL3Jlc3RhdXJhbnQtZGV0YWlsL3Jlc3RhdXJhbnQtZGV0YWlsLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts ***!
  \*************************************************************************/
/*! exports provided: RestaurantDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestaurantDetailPage", function() { return RestaurantDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_restaurant_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/restaurant.service */ "./src/app/services/restaurant.service.ts");
/* harmony import */ var _restaurant_detail_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./restaurant-detail.service */ "./src/app/restaurants/restaurant-detail/restaurant-detail.service.ts");
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/database */ "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-database.js");



//import { Restaurant } from '../restaurant.model';
//import { RestaurantsService } from '../restaurants.service';



let RestaurantDetailPage = class RestaurantDetailPage {
    constructor(activatedRoute, 
    //private restaurantsService: RestaurantsService,
    restoService, restaurantDetailService, db) {
        this.activatedRoute = activatedRoute;
        this.restoService = restoService;
        this.restaurantDetailService = restaurantDetailService;
        this.db = db;
    }
    ngOnInit() {
        // this.activatedRoute.paramMap.subscribe( paramMap => {
        //   if (!paramMap.has('key')) { return; }
        //   const restaurantId = paramMap.get('key');
        //   this.loadedRestaurant = this.restaurantsService.getRestaurant(restaurantId);
        // });
    }
    ionViewWillEnter() {
        this.activatedRoute.paramMap.subscribe(paramMap => {
            if (!paramMap.has('key')) {
                return;
            }
            this.key = paramMap.get('key');
            this.db.object('/restaurant/' + this.key).valueChanges().subscribe(data => {
                console.log('data: ', data);
                this.loadedResto = data;
                console.log('this.loadedResto: ', this.loadedResto);
            });
        });
        this.foods = this.restaurantDetailService.getAllFoods();
    }
};
RestaurantDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: src_app_services_restaurant_service__WEBPACK_IMPORTED_MODULE_3__["RestaurantService"] },
    { type: _restaurant_detail_service__WEBPACK_IMPORTED_MODULE_4__["RestaurantDetailService"] },
    { type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__["AngularFireDatabase"] }
];
RestaurantDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-restaurant-detail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./restaurant-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/restaurants/restaurant-detail/restaurant-detail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./restaurant-detail.page.scss */ "./src/app/restaurants/restaurant-detail/restaurant-detail.page.scss")).default]
    })
], RestaurantDetailPage);



/***/ }),

/***/ "./src/app/restaurants/restaurant-detail/restaurant-detail.service.ts":
/*!****************************************************************************!*\
  !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.service.ts ***!
  \****************************************************************************/
/*! exports provided: RestaurantDetailService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestaurantDetailService", function() { return RestaurantDetailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let RestaurantDetailService = class RestaurantDetailService {
    constructor() {
        this.foods = [
            {
                id_food: '1',
                name: 'Rendang',
                imageUrl: 'https://assets.pikiran-rakyat.com/crop/0x0:0x0/x/photo/2020/05/23/2598383914.jpg',
                desc: 'Perpaduan kelembutan daging sapi dan bumbu rendang',
                harga: 'Rp.10.000'
            },
            {
                id_food: '2',
                name: 'Nasi Putih',
                imageUrl: 'https://ecs7.tokopedia.net/img/cache/700/product-1/2017/12/11/20991395/20991395_f22e6791-b0bd-40aa-8734-0b4f8d697bd0_501_501.jpg',
                desc: 'Diolah dari beras pilihan',
                harga: 'Rp.5.000'
            },
            {
                id_food: 'Sambal Ijo',
                name: 'Rendang',
                imageUrl: 'https://1.bp.blogspot.com/-aIlI9t2CZRs/XxHIHi-EcYI/AAAAAAABz0g/CMloeTLu7O49asC7WKJ7wzJxFtehwAMrACLcBGAsYHQ/s750/resep%2Bsambal%2Bijo1.jpg',
                desc: 'Cabai segar yang diolah dengan baik',
                harga: 'Rp.7.000'
            }
        ];
    }
    getAllFoods() {
        console.log('foods: ', this.foods);
        return [...this.foods];
    }
    getFoods(foodId) {
        return Object.assign({}, this.foods.find(foods => {
            return foods.id_food === foodId;
        }));
    }
};
RestaurantDetailService.ctorParameters = () => [];
RestaurantDetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RestaurantDetailService);



/***/ })

}]);
//# sourceMappingURL=restaurant-detail-restaurant-detail-module-es2015.js.map