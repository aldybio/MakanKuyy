(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forgotpass1-forgotpass1-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/forgotpass1/forgotpass1.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/forgotpass1/forgotpass1.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"primary\" defaultHref=\"login\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title>Forgot Password</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid justify-content-center align-items-center>\n    <ion-row>\n      <ion-col  size=\"12\" size-sm=\"8\" offset-sm=\"2\">\n        <br><br><br><br>        \n        <h2>Step 1 Masukan Kode</h2>\n      </ion-col>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\">\n        <form   #form=\"ngForm\" (ngSubmit)=\"onSubmit(form)\"class=\"list-form\">\n          <ion-item>\n            <ion-label floating>\n              Kode : \n            </ion-label>\n            <ion-input type=\"text\" name=\"kode\"></ion-input>\n          </ion-item>\n        </form>      \n\n        <ion-button expand=\"block\" shape=\"round\" color=\"primary\" href=\"forgotpass2\">Reset Password</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/forgotpass1/forgotpass1-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/forgotpass1/forgotpass1-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: Forgotpass1PageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Forgotpass1PageRoutingModule", function() { return Forgotpass1PageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _forgotpass1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgotpass1.page */ "./src/app/forgotpass1/forgotpass1.page.ts");




const routes = [
    {
        path: '',
        component: _forgotpass1_page__WEBPACK_IMPORTED_MODULE_3__["Forgotpass1Page"]
    }
];
let Forgotpass1PageRoutingModule = class Forgotpass1PageRoutingModule {
};
Forgotpass1PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], Forgotpass1PageRoutingModule);



/***/ }),

/***/ "./src/app/forgotpass1/forgotpass1.module.ts":
/*!***************************************************!*\
  !*** ./src/app/forgotpass1/forgotpass1.module.ts ***!
  \***************************************************/
/*! exports provided: Forgotpass1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Forgotpass1PageModule", function() { return Forgotpass1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _forgotpass1_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./forgotpass1-routing.module */ "./src/app/forgotpass1/forgotpass1-routing.module.ts");
/* harmony import */ var _forgotpass1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./forgotpass1.page */ "./src/app/forgotpass1/forgotpass1.page.ts");







let Forgotpass1PageModule = class Forgotpass1PageModule {
};
Forgotpass1PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _forgotpass1_routing_module__WEBPACK_IMPORTED_MODULE_5__["Forgotpass1PageRoutingModule"]
        ],
        declarations: [_forgotpass1_page__WEBPACK_IMPORTED_MODULE_6__["Forgotpass1Page"]]
    })
], Forgotpass1PageModule);



/***/ }),

/***/ "./src/app/forgotpass1/forgotpass1.page.scss":
/*!***************************************************!*\
  !*** ./src/app/forgotpass1/forgotpass1.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2ZvcmdvdHBhc3MxL2ZvcmdvdHBhc3MxLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/forgotpass1/forgotpass1.page.ts":
/*!*************************************************!*\
  !*** ./src/app/forgotpass1/forgotpass1.page.ts ***!
  \*************************************************/
/*! exports provided: Forgotpass1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Forgotpass1Page", function() { return Forgotpass1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let Forgotpass1Page = class Forgotpass1Page {
    constructor() { }
    ngOnInit() {
    }
};
Forgotpass1Page.ctorParameters = () => [];
Forgotpass1Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-forgotpass1',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./forgotpass1.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/forgotpass1/forgotpass1.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./forgotpass1.page.scss */ "./src/app/forgotpass1/forgotpass1.page.scss")).default]
    })
], Forgotpass1Page);



/***/ })

}]);
//# sourceMappingURL=forgotpass1-forgotpass1-module-es2015.js.map