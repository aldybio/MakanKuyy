(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-resto-edit-resto-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/edit-resto.page.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/edit-resto.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/admin/restaurants\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Admin - Restaurant Detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"primary\">\n  <ion-card style=\"width: 100%; margin: auto;\">\n    <ion-list color=\"primary\">\n      <ion-row color=\"primary\">\n        <ion-col color=\"primary\">\n          <ion-item color=\"primary\">\n            <ion-avatar style=\"block-size: 150px; width:150px;\" color=\"primary\">\n              <ion-img [src]=\"resto_image\"></ion-img>\n            </ion-avatar>\n            <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\n              <ion-input type=\"text\" name=\"resto_name\" ngModel></ion-input>\n              <ion-input type=\"text\" name=\"resto_hour_open\" ngModel></ion-input> - <ion-input type=\"text\" name=\"resto_hour_close\" ngModel></ion-input>\n              <ion-input type=\"text\" name=\"resto_address\" ngModel></ion-input>\n              <ion-input ngModel type=\"text\" name=\"resto_city\"></ion-input>\n              <ion-input type=\"text\" name=\"resto_image\" ngModel></ion-input>\n            </form>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <!-- <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-list color=\"secondary\" class=\"detail-recipe\">\n              <ion-item color=\"secondary\" *ngFor=\"let food of foods\">\n                <ion-avatar class=\"avatar-food\" slot=\"start\" style=\"block-size: 90px; width:90px; margin: 2% 0;\">\n                  <ion-img [src]=\"food.imageUrl\"></ion-img>\n                </ion-avatar>\n                <ion-label style=\"margin-left: 2%;\">\n                  <p>{{food.name}}</p>\n                  <small>{{food.desc}}</small>\n                  <p>Harga : {{food.harga}}</p>\n                  <button [routerLink]=\"/edit-menu\">\n                    <ion-icon name=\"pencil\"></ion-icon>\n                  </button>\n                  <button (click)=\"deleteMenu(menu.key)\">\n                    <ion-icon name=\"trash\"></ion-icon>\n                  </button>\n                </ion-label>\n              </ion-item> \n              <button [routerLink]=\"add-menu\">Add a Menu</button>\n            </ion-list>\n          </ion-col> \n        </ion-row>\n      </ion-grid> -->\n    </ion-list>\n  </ion-card>\n</ion-content>");

/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/edit-resto-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/edit-resto-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: EditRestoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditRestoPageRoutingModule", function() { return EditRestoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _edit_resto_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-resto.page */ "./src/app/admin/restaurants/edit-resto/edit-resto.page.ts");




const routes = [
    {
        path: '',
        component: _edit_resto_page__WEBPACK_IMPORTED_MODULE_3__["EditRestoPage"]
    },
    {
        path: 'add-menu',
        loadChildren: () => __webpack_require__.e(/*! import() | add-menu-add-menu-module */ "add-menu-add-menu-module").then(__webpack_require__.bind(null, /*! ./add-menu/add-menu.module */ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.module.ts")).then(m => m.AddMenuPageModule)
    },
    {
        path: 'edit-menu',
        loadChildren: () => __webpack_require__.e(/*! import() | edit-menu-edit-menu-module */ "edit-menu-edit-menu-module").then(__webpack_require__.bind(null, /*! ./edit-menu/edit-menu.module */ "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.module.ts")).then(m => m.EditMenuPageModule)
    }
];
let EditRestoPageRoutingModule = class EditRestoPageRoutingModule {
};
EditRestoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditRestoPageRoutingModule);



/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/edit-resto.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/edit-resto.module.ts ***!
  \*******************************************************************/
/*! exports provided: EditRestoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditRestoPageModule", function() { return EditRestoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _edit_resto_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-resto-routing.module */ "./src/app/admin/restaurants/edit-resto/edit-resto-routing.module.ts");
/* harmony import */ var _edit_resto_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-resto.page */ "./src/app/admin/restaurants/edit-resto/edit-resto.page.ts");







let EditRestoPageModule = class EditRestoPageModule {
};
EditRestoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_resto_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditRestoPageRoutingModule"]
        ],
        declarations: [_edit_resto_page__WEBPACK_IMPORTED_MODULE_6__["EditRestoPage"]]
    })
], EditRestoPageModule);



/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/edit-resto.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/edit-resto.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3Jlc3RhdXJhbnRzL2VkaXQtcmVzdG8vZWRpdC1yZXN0by5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/edit-resto.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/edit-resto.page.ts ***!
  \*****************************************************************/
/*! exports provided: EditRestoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditRestoPage", function() { return EditRestoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/database */ "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-database.js");
/* harmony import */ var _services_restaurant_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/restaurant.service */ "./src/app/services/restaurant.service.ts");





let EditRestoPage = class EditRestoPage {
    constructor(activatedRoute, restoService, db) {
        this.activatedRoute = activatedRoute;
        this.restoService = restoService;
        this.db = db;
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.activatedRoute.paramMap.subscribe(paramMap => {
            if (!paramMap.has('key')) {
                return;
            }
            this.key = paramMap.get('key');
            this.db.object('/restaurant/' + this.key).valueChanges().subscribe(data => {
                console.log('data: ', data);
                this.loadedResto = data;
                console.log('this.loadedResto: ', this.loadedResto);
            });
        });
        setTimeout(() => {
            this.f.setValue(this.loadedResto);
        });
    }
};
EditRestoPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _services_restaurant_service__WEBPACK_IMPORTED_MODULE_4__["RestaurantService"] },
    { type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_3__["AngularFireDatabase"] }
];
EditRestoPage.propDecorators = {
    f: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"], args: ['f', null,] }]
};
EditRestoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit-resto',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./edit-resto.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/edit-resto.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./edit-resto.page.scss */ "./src/app/admin/restaurants/edit-resto/edit-resto.page.scss")).default]
    })
], EditRestoPage);



/***/ })

}]);
//# sourceMappingURL=edit-resto-edit-resto-module-es2015.js.map