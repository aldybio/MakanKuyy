(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["admin-restaurants-restaurants-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/restaurants.page.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/restaurants.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppAdminRestaurantsRestaurantsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Admin - Restaurants</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button routerLink=\"add-resto\">Add</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div *ngFor=\"let resto of restos\">\n    <ion-card [routerLink]=\"['./', resto.key]\" style=\"width: 30%; display: flex; justify-content: center;\">\n      <ion-item>\n        <ion-avatar style=\"block-size: 120px; width:120px; margin-right: 20%;\">\n          <img src=\"{{resto.resto_image}}\">\n        </ion-avatar>\n      </ion-item>\n      <ion-card-header>\n        <ion-card-title>{{resto.resto_name}}</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n        <p>Open: {{resto.resto_hour_open}} - {{resto.resto_hour_close}}</p>\n        <p>Address: {{resto.resto_address}}, {{resto.resto_city}}</p>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/admin/restaurants/restaurants-routing.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/admin/restaurants/restaurants-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: RestaurantsPageRoutingModule */

    /***/
    function srcAppAdminRestaurantsRestaurantsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantsPageRoutingModule", function () {
        return RestaurantsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _restaurants_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./restaurants.page */
      "./src/app/admin/restaurants/restaurants.page.ts");

      var routes = [{
        path: '',
        component: _restaurants_page__WEBPACK_IMPORTED_MODULE_3__["RestaurantsPage"]
      }, {
        path: 'add-resto',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | add-resto-add-resto-module */
          "add-resto-add-resto-module").then(__webpack_require__.bind(null,
          /*! ./add-resto/add-resto.module */
          "./src/app/admin/restaurants/add-resto/add-resto.module.ts")).then(function (m) {
            return m.AddRestoPageModule;
          });
        }
      }, {
        path: ':key',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | edit-resto-edit-resto-module */
          "edit-resto-edit-resto-module").then(__webpack_require__.bind(null,
          /*! ./edit-resto/edit-resto.module */
          "./src/app/admin/restaurants/edit-resto/edit-resto.module.ts")).then(function (m) {
            return m.EditRestoPageModule;
          });
        }
      }];

      var RestaurantsPageRoutingModule = function RestaurantsPageRoutingModule() {
        _classCallCheck(this, RestaurantsPageRoutingModule);
      };

      RestaurantsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], RestaurantsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/admin/restaurants/restaurants.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/admin/restaurants/restaurants.module.ts ***!
      \*********************************************************/

    /*! exports provided: RestaurantsPageModule */

    /***/
    function srcAppAdminRestaurantsRestaurantsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantsPageModule", function () {
        return RestaurantsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _restaurants_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./restaurants-routing.module */
      "./src/app/admin/restaurants/restaurants-routing.module.ts");
      /* harmony import */


      var _restaurants_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./restaurants.page */
      "./src/app/admin/restaurants/restaurants.page.ts");

      var RestaurantsPageModule = function RestaurantsPageModule() {
        _classCallCheck(this, RestaurantsPageModule);
      };

      RestaurantsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _restaurants_routing_module__WEBPACK_IMPORTED_MODULE_5__["RestaurantsPageRoutingModule"]],
        declarations: [_restaurants_page__WEBPACK_IMPORTED_MODULE_6__["RestaurantsPage"]]
      })], RestaurantsPageModule);
      /***/
    },

    /***/
    "./src/app/admin/restaurants/restaurants.page.scss":
    /*!*********************************************************!*\
      !*** ./src/app/admin/restaurants/restaurants.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppAdminRestaurantsRestaurantsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3Jlc3RhdXJhbnRzL3Jlc3RhdXJhbnRzLnBhZ2Uuc2NzcyJ9 */";
      /***/
    },

    /***/
    "./src/app/admin/restaurants/restaurants.page.ts":
    /*!*******************************************************!*\
      !*** ./src/app/admin/restaurants/restaurants.page.ts ***!
      \*******************************************************/

    /*! exports provided: RestaurantsPage */

    /***/
    function srcAppAdminRestaurantsRestaurantsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantsPage", function () {
        return RestaurantsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_restaurant_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../../services/restaurant.service */
      "./src/app/services/restaurant.service.ts");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs/operators */
      "./node_modules/rxjs/_esm2015/operators/index.js");

      var RestaurantsPage = /*#__PURE__*/function () {
        function RestaurantsPage(restoService) {
          _classCallCheck(this, RestaurantsPage);

          this.restoService = restoService;
        }

        _createClass(RestaurantsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.restoService.getAllResto().snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (changes) {
              return changes.map(function (c) {
                return Object.assign({
                  key: c.payload.key
                }, c.payload.val());
              });
            })).subscribe(function (data) {
              _this.restos = data;
              console.log('Resto: ', data);
            });
          }
        }]);

        return RestaurantsPage;
      }();

      RestaurantsPage.ctorParameters = function () {
        return [{
          type: _services_restaurant_service__WEBPACK_IMPORTED_MODULE_2__["RestaurantService"]
        }];
      };

      RestaurantsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-restaurants',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./restaurants.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/restaurants.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./restaurants.page.scss */
        "./src/app/admin/restaurants/restaurants.page.scss"))["default"]]
      })], RestaurantsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=admin-restaurants-restaurants-module-es5.js.map