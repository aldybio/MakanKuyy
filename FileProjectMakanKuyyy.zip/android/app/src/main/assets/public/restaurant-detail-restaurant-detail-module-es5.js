(function () {
  function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

  function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

  function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["restaurant-detail-restaurant-detail-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/restaurants/restaurant-detail/restaurant-detail.page.html":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/restaurants/restaurant-detail/restaurant-detail.page.html ***!
      \*****************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppRestaurantsRestaurantDetailRestaurantDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{resto_name}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"primary\">\n  <ion-card style=\"width: 100%; margin: auto;\">\n    <ion-list color=\"primary\">\n      <ion-row color=\"primary\">\n        <ion-col color=\"primary\">\n          <ion-item color=\"primary\">\n          <ion-avatar style=\"block-size: 150px; width:150px;\" color=\"primary\">\n            <ion-img [src]=\"resto_image\"></ion-img>\n          </ion-avatar>\n          <ion-label style=\"margin-left: 2%;\" color=\"secondary\">\n            {{resto_name}}<br>{{resto_hour_open}} - {{resto_hour_close}}<br>\n            <small>{{resto_address}}, {{resto_city}}</small><br>\n            <!-- <ion-icon color=\"tertiary\" name=\"document-text-outline\"></ion-icon>\n            <ion-icon color=\"danger\" name=\"close-circle-outline\"></ion-icon> -->\n            <div style=\"width: 75%; border-radius: 10px; background-color: #002c49; text-align: center; padding: 5px; margin: 10px auto 0\" color=\"secondary\">\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n              <ion-icon name=\"star\" style=\"color: #fcd303\"></ion-icon>\n            </div>\n            <br><br><br>\n          </ion-label>\n        </ion-item>\n        </ion-col>\n      </ion-row>\n      \n      <!-- <ion-row>\n        <ion-col>\n          <ion-item color=\"warning\"><h1>{{loadedRestaurant.name}} </h1></ion-item>\n        </ion-col>\n      </ion-row> -->\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-list color=\"secondary\" class=\"detail-recipe\">\n              <!-- <ion-item color=\"medium\" *ngFor=\"let food of foods\">\n                <ion-avatar slot=\"start\" style=\"block-size: 90px; width:90px; margin-top: 2%; margin-bottom: 2%;\">\n                  <ion-img [src]=\"food.imageUrl\"></ion-img>\n                </ion-avatar>\n                <ion-label style=\"margin-left: 2%;\">\n                  {{food.name}}<br>\n                  Desc : {{food.desc}}<br>\n                  Harga : {{food.harga}}\n                </ion-label>\n              </ion-item> -->\n\n              <ion-item color=\"secondary\" *ngFor=\"let food of foods\">\n                <ion-avatar class=\"avatar-food\" slot=\"start\" style=\"block-size: 90px; width:90px; margin: 2% 0;\">\n                  <ion-img [src]=\"food.imageUrl\"></ion-img>\n                </ion-avatar>\n                <ion-label style=\"margin-left: 2%;\">\n                  <p>{{food.name}}</p>\n                  <small>{{food.desc}}</small>\n                  <p>Harga : {{food.harga}}</p>\n                </ion-label>\n              </ion-item>\n\n            </ion-list>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </ion-list>\n  </ion-card>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/restaurants/restaurant-detail/restaurant-detail-routing.module.ts":
    /*!***********************************************************************************!*\
      !*** ./src/app/restaurants/restaurant-detail/restaurant-detail-routing.module.ts ***!
      \***********************************************************************************/

    /*! exports provided: RestaurantDetailPageRoutingModule */

    /***/
    function srcAppRestaurantsRestaurantDetailRestaurantDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantDetailPageRoutingModule", function () {
        return RestaurantDetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _restaurant_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./restaurant-detail.page */
      "./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts");

      var routes = [{
        path: '',
        component: _restaurant_detail_page__WEBPACK_IMPORTED_MODULE_3__["RestaurantDetailPage"]
      }];

      var RestaurantDetailPageRoutingModule = function RestaurantDetailPageRoutingModule() {
        _classCallCheck(this, RestaurantDetailPageRoutingModule);
      };

      RestaurantDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], RestaurantDetailPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/restaurants/restaurant-detail/restaurant-detail.module.ts":
    /*!***************************************************************************!*\
      !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.module.ts ***!
      \***************************************************************************/

    /*! exports provided: RestaurantDetailPageModule */

    /***/
    function srcAppRestaurantsRestaurantDetailRestaurantDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantDetailPageModule", function () {
        return RestaurantDetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _restaurant_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./restaurant-detail-routing.module */
      "./src/app/restaurants/restaurant-detail/restaurant-detail-routing.module.ts");
      /* harmony import */


      var _restaurant_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./restaurant-detail.page */
      "./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts");

      var RestaurantDetailPageModule = function RestaurantDetailPageModule() {
        _classCallCheck(this, RestaurantDetailPageModule);
      };

      RestaurantDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _restaurant_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["RestaurantDetailPageRoutingModule"]],
        declarations: [_restaurant_detail_page__WEBPACK_IMPORTED_MODULE_6__["RestaurantDetailPage"]]
      })], RestaurantDetailPageModule);
      /***/
    },

    /***/
    "./src/app/restaurants/restaurant-detail/restaurant-detail.page.scss":
    /*!***************************************************************************!*\
      !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.page.scss ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppRestaurantsRestaurantDetailRestaurantDetailPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Jlc3RhdXJhbnRzL3Jlc3RhdXJhbnQtZGV0YWlsL3Jlc3RhdXJhbnQtZGV0YWlsLnBhZ2Uuc2NzcyJ9 */";
      /***/
    },

    /***/
    "./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts":
    /*!*************************************************************************!*\
      !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.page.ts ***!
      \*************************************************************************/

    /*! exports provided: RestaurantDetailPage */

    /***/
    function srcAppRestaurantsRestaurantDetailRestaurantDetailPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantDetailPage", function () {
        return RestaurantDetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var src_app_services_restaurant_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/services/restaurant.service */
      "./src/app/services/restaurant.service.ts");
      /* harmony import */


      var _restaurant_detail_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./restaurant-detail.service */
      "./src/app/restaurants/restaurant-detail/restaurant-detail.service.ts");
      /* harmony import */


      var _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/fire/database */
      "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-database.js"); //import { Restaurant } from '../restaurant.model';
      //import { RestaurantsService } from '../restaurants.service';


      var RestaurantDetailPage = /*#__PURE__*/function () {
        function RestaurantDetailPage(activatedRoute, //private restaurantsService: RestaurantsService,
        restoService, restaurantDetailService, db) {
          _classCallCheck(this, RestaurantDetailPage);

          this.activatedRoute = activatedRoute;
          this.restoService = restoService;
          this.restaurantDetailService = restaurantDetailService;
          this.db = db;
        }

        _createClass(RestaurantDetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {// this.activatedRoute.paramMap.subscribe( paramMap => {
            //   if (!paramMap.has('key')) { return; }
            //   const restaurantId = paramMap.get('key');
            //   this.loadedRestaurant = this.restaurantsService.getRestaurant(restaurantId);
            // });
          }
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            var _this = this;

            this.activatedRoute.paramMap.subscribe(function (paramMap) {
              if (!paramMap.has('key')) {
                return;
              }

              _this.key = paramMap.get('key');

              _this.db.object('/restaurant/' + _this.key).valueChanges().subscribe(function (data) {
                console.log('data: ', data);
                _this.loadedResto = data;
                console.log('this.loadedResto: ', _this.loadedResto);
              });
            });
            this.foods = this.restaurantDetailService.getAllFoods();
          }
        }]);

        return RestaurantDetailPage;
      }();

      RestaurantDetailPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
        }, {
          type: src_app_services_restaurant_service__WEBPACK_IMPORTED_MODULE_3__["RestaurantService"]
        }, {
          type: _restaurant_detail_service__WEBPACK_IMPORTED_MODULE_4__["RestaurantDetailService"]
        }, {
          type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__["AngularFireDatabase"]
        }];
      };

      RestaurantDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-restaurant-detail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./restaurant-detail.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/restaurants/restaurant-detail/restaurant-detail.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./restaurant-detail.page.scss */
        "./src/app/restaurants/restaurant-detail/restaurant-detail.page.scss"))["default"]]
      })], RestaurantDetailPage);
      /***/
    },

    /***/
    "./src/app/restaurants/restaurant-detail/restaurant-detail.service.ts":
    /*!****************************************************************************!*\
      !*** ./src/app/restaurants/restaurant-detail/restaurant-detail.service.ts ***!
      \****************************************************************************/

    /*! exports provided: RestaurantDetailService */

    /***/
    function srcAppRestaurantsRestaurantDetailRestaurantDetailServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RestaurantDetailService", function () {
        return RestaurantDetailService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var RestaurantDetailService = /*#__PURE__*/function () {
        function RestaurantDetailService() {
          _classCallCheck(this, RestaurantDetailService);

          this.foods = [{
            id_food: '1',
            name: 'Rendang',
            imageUrl: 'https://assets.pikiran-rakyat.com/crop/0x0:0x0/x/photo/2020/05/23/2598383914.jpg',
            desc: 'Perpaduan kelembutan daging sapi dan bumbu rendang',
            harga: 'Rp.10.000'
          }, {
            id_food: '2',
            name: 'Nasi Putih',
            imageUrl: 'https://ecs7.tokopedia.net/img/cache/700/product-1/2017/12/11/20991395/20991395_f22e6791-b0bd-40aa-8734-0b4f8d697bd0_501_501.jpg',
            desc: 'Diolah dari beras pilihan',
            harga: 'Rp.5.000'
          }, {
            id_food: 'Sambal Ijo',
            name: 'Rendang',
            imageUrl: 'https://1.bp.blogspot.com/-aIlI9t2CZRs/XxHIHi-EcYI/AAAAAAABz0g/CMloeTLu7O49asC7WKJ7wzJxFtehwAMrACLcBGAsYHQ/s750/resep%2Bsambal%2Bijo1.jpg',
            desc: 'Cabai segar yang diolah dengan baik',
            harga: 'Rp.7.000'
          }];
        }

        _createClass(RestaurantDetailService, [{
          key: "getAllFoods",
          value: function getAllFoods() {
            console.log('foods: ', this.foods);
            return _toConsumableArray(this.foods);
          }
        }, {
          key: "getFoods",
          value: function getFoods(foodId) {
            return Object.assign({}, this.foods.find(function (foods) {
              return foods.id_food === foodId;
            }));
          }
        }]);

        return RestaurantDetailService;
      }();

      RestaurantDetailService.ctorParameters = function () {
        return [];
      };

      RestaurantDetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], RestaurantDetailService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=restaurant-detail-restaurant-detail-module-es5.js.map