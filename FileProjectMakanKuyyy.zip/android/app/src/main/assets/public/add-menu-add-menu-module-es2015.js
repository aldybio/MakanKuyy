(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-menu-add-menu-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"end\">\n      <ion-back-button defaultHref=\"\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>New Menu</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Name</ion-label>\n        <ion-input type=\"text\" hidden ngModel name=\"resto_key\">TestHidden</ion-input>\n        <ion-input type=\"text\" ngModel name=\"menu_name\">Test</ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Description</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_desc\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Price</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_price\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Image URL</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_image\"></ion-input>\n      </ion-item>\n      <ion-button type=\"submit\" color=\"primary\" expand=\"block\">Save</ion-button>\n    </ion-list>\n  </form>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu-routing.module.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/add-menu/add-menu-routing.module.ts ***!
  \**********************************************************************************/
/*! exports provided: AddMenuPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddMenuPageRoutingModule", function() { return AddMenuPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _add_menu_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-menu.page */ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.ts");




const routes = [
    {
        path: '',
        component: _add_menu_page__WEBPACK_IMPORTED_MODULE_3__["AddMenuPage"]
    }
];
let AddMenuPageRoutingModule = class AddMenuPageRoutingModule {
};
AddMenuPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddMenuPageRoutingModule);



/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/add-menu/add-menu.module.ts ***!
  \**************************************************************************/
/*! exports provided: AddMenuPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddMenuPageModule", function() { return AddMenuPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _add_menu_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-menu-routing.module */ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu-routing.module.ts");
/* harmony import */ var _add_menu_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-menu.page */ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.ts");







let AddMenuPageModule = class AddMenuPageModule {
};
AddMenuPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_menu_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddMenuPageRoutingModule"]
        ],
        declarations: [_add_menu_page__WEBPACK_IMPORTED_MODULE_6__["AddMenuPage"]]
    })
], AddMenuPageModule);



/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.scss":
/*!**************************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3Jlc3RhdXJhbnRzL2VkaXQtcmVzdG8vYWRkLW1lbnUvYWRkLW1lbnUucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.ts":
/*!************************************************************************!*\
  !*** ./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.ts ***!
  \************************************************************************/
/*! exports provided: AddMenuPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddMenuPage", function() { return AddMenuPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let AddMenuPage = class AddMenuPage {
    constructor() { }
    ngOnInit() {
    }
};
AddMenuPage.ctorParameters = () => [];
AddMenuPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-menu',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./add-menu.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./add-menu.page.scss */ "./src/app/admin/restaurants/edit-resto/add-menu/add-menu.page.scss")).default]
    })
], AddMenuPage);



/***/ })

}]);
//# sourceMappingURL=add-menu-add-menu-module-es2015.js.map