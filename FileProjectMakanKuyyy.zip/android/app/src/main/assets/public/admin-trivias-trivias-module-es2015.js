(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["admin-trivias-trivias-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/trivias/trivias.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/trivias/trivias.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Trivias</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button href=\"admin/trivias/add-trivia\">Add</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item *ngFor=\"let trivia of trivias\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>\n          {{trivia.content}}\n        </ion-card-title>\n        <ion-card-subtitle>\n          {{trivia.source}}\n        </ion-card-subtitle>\n      </ion-card-header>\n    </ion-card>\n  </ion-item>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/admin/trivias/trivias-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/admin/trivias/trivias-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: TriviasPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TriviasPageRoutingModule", function() { return TriviasPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _trivias_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trivias.page */ "./src/app/admin/trivias/trivias.page.ts");




const routes = [
    {
        path: '',
        component: _trivias_page__WEBPACK_IMPORTED_MODULE_3__["TriviasPage"]
    },
    {
        path: 'add-trivia',
        loadChildren: () => __webpack_require__.e(/*! import() | add-trivia-add-trivia-module */ "add-trivia-add-trivia-module").then(__webpack_require__.bind(null, /*! ./add-trivia/add-trivia.module */ "./src/app/admin/trivias/add-trivia/add-trivia.module.ts")).then(m => m.AddTriviaPageModule)
    }
];
let TriviasPageRoutingModule = class TriviasPageRoutingModule {
};
TriviasPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TriviasPageRoutingModule);



/***/ }),

/***/ "./src/app/admin/trivias/trivias.module.ts":
/*!*************************************************!*\
  !*** ./src/app/admin/trivias/trivias.module.ts ***!
  \*************************************************/
/*! exports provided: TriviasPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TriviasPageModule", function() { return TriviasPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _trivias_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./trivias-routing.module */ "./src/app/admin/trivias/trivias-routing.module.ts");
/* harmony import */ var _trivias_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trivias.page */ "./src/app/admin/trivias/trivias.page.ts");







let TriviasPageModule = class TriviasPageModule {
};
TriviasPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _trivias_routing_module__WEBPACK_IMPORTED_MODULE_5__["TriviasPageRoutingModule"]
        ],
        declarations: [_trivias_page__WEBPACK_IMPORTED_MODULE_6__["TriviasPage"]]
    })
], TriviasPageModule);



/***/ }),

/***/ "./src/app/admin/trivias/trivias.page.scss":
/*!*************************************************!*\
  !*** ./src/app/admin/trivias/trivias.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3RyaXZpYXMvdHJpdmlhcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/admin/trivias/trivias.page.ts":
/*!***********************************************!*\
  !*** ./src/app/admin/trivias/trivias.page.ts ***!
  \***********************************************/
/*! exports provided: TriviasPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TriviasPage", function() { return TriviasPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_trivia_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/trivia.service */ "./src/app/services/trivia.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");


 //service

let TriviasPage = class TriviasPage {
    constructor(triviaService) {
        this.triviaService = triviaService;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.triviaService.getAllTrivia().snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(changes => changes.map(c => (Object.assign({ key: c.payload.key }, c.payload.val()))))).subscribe(data => {
            this.trivias = data;
            console.log('Trivias: ', this.trivias);
        });
    }
};
TriviasPage.ctorParameters = () => [
    { type: src_app_services_trivia_service__WEBPACK_IMPORTED_MODULE_2__["TriviaService"] }
];
TriviasPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-trivias',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./trivias.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/trivias/trivias.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./trivias.page.scss */ "./src/app/admin/trivias/trivias.page.scss")).default]
    })
], TriviasPage);



/***/ }),

/***/ "./src/app/services/trivia.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/trivia.service.ts ***!
  \********************************************/
/*! exports provided: TriviaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TriviaService", function() { return TriviaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/database */ "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-database.js");



let TriviaService = class TriviaService {
    constructor(db) {
        this.db = db;
        this.dbPath = '/trivia/';
        this.triviaRef = null;
        this.triviaRef = db.list(this.dbPath); // ambil list dari tabel database
    }
    getAllTrivia() {
        return this.triviaRef; //pass seluruh trivia
    }
    addTrivia(trivia) {
        return this.triviaRef.push(trivia); //push trivia baru ke list trivia
    }
    deleteTrivia(key) {
        return this.triviaRef.remove(key); //hapus trivia dgn key tsb dari list
    }
    updateTrivia(key, trivia) {
    }
};
TriviaService.ctorParameters = () => [
    { type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_2__["AngularFireDatabase"] }
];
TriviaService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], TriviaService);



/***/ })

}]);
//# sourceMappingURL=admin-trivias-trivias-module-es2015.js.map