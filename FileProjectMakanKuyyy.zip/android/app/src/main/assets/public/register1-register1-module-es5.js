(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register1-register1-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/register1/register1.page.html":
    /*!*************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register1/register1.page.html ***!
      \*************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppRegister1Register1PageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"primary\" defaultHref=\"register1\">\n\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n    <ion-title>Register Step 2</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  \n<!-- <ion-grid justify-content-center align-items-center>\n  <ion-row>\n     <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\">\n      <form   #form=\"ngForm\" (ngSubmit)=\"onSubmit(form)\" class=\"list-form\">\n        <ion-item>\n          <ion-label floating>\n            NIK : \n          </ion-label>\n          <ion-input type=\"number\"></ion-input>\n        </ion-item>\n      </form>      \n\n      <ion-button expand=\"block\" shape=\"round\" color=\"primary\" href=\"login\">Sign Up</ion-button>\n     </ion-col>\n  </ion-row>\n</ion-grid> -->\n\n<ion-grid>\n  <ion-row>\n    <h2>Ionic 4 Firebase Verify Email</h2><br>\n    <p>\n      Please check your email and click on the link to verfiy your email address.\n    </p>\n    <ion-button type=\"submit\" (click)=\"authService.SendVerificationMail()\" expand=\"block\">\n      Resend Verification Email\n    </ion-button>\n    <ion-button type=\"submit\" href=\"/login\" expand=\"block\">Login</ion-button>\n  </ion-row>\n</ion-grid>\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/register1/register1-routing.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/register1/register1-routing.module.ts ***!
      \*******************************************************/

    /*! exports provided: Register1PageRoutingModule */

    /***/
    function srcAppRegister1Register1RoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Register1PageRoutingModule", function () {
        return Register1PageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _register1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./register1.page */
      "./src/app/register1/register1.page.ts");

      var routes = [{
        path: '',
        component: _register1_page__WEBPACK_IMPORTED_MODULE_3__["Register1Page"]
      }];

      var Register1PageRoutingModule = function Register1PageRoutingModule() {
        _classCallCheck(this, Register1PageRoutingModule);
      };

      Register1PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], Register1PageRoutingModule);
      /***/
    },

    /***/
    "./src/app/register1/register1.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/register1/register1.module.ts ***!
      \***********************************************/

    /*! exports provided: Register1PageModule */

    /***/
    function srcAppRegister1Register1ModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Register1PageModule", function () {
        return Register1PageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _register1_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./register1-routing.module */
      "./src/app/register1/register1-routing.module.ts");
      /* harmony import */


      var _register1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./register1.page */
      "./src/app/register1/register1.page.ts");

      var Register1PageModule = function Register1PageModule() {
        _classCallCheck(this, Register1PageModule);
      };

      Register1PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _register1_routing_module__WEBPACK_IMPORTED_MODULE_5__["Register1PageRoutingModule"]],
        declarations: [_register1_page__WEBPACK_IMPORTED_MODULE_6__["Register1Page"]]
      })], Register1PageModule);
      /***/
    },

    /***/
    "./src/app/register1/register1.page.scss":
    /*!***********************************************!*\
      !*** ./src/app/register1/register1.page.scss ***!
      \***********************************************/

    /*! exports provided: default */

    /***/
    function srcAppRegister1Register1PageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "button {\n  background: #ADFD87;\n  border: 2px solid #000000;\n  box-sizing: border-box;\n  border-radius: 20px;\n  height: 52px;\n  width: 343px;\n  left: 28px;\n  top: 431px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIxL3JlZ2lzdGVyMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyMS9yZWdpc3RlcjEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYnV0dG9ueyAgICBcclxuICAgIGJhY2tncm91bmQ6ICNBREZEODc7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjMDAwMDAwO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDUycHg7XHJcbiAgICB3aWR0aDogMzQzcHg7XHJcbiAgICBsZWZ0OiAyOHB4O1xyXG4gICAgdG9wOiA0MzFweDtcclxuICAgIH0iXX0= */";
      /***/
    },

    /***/
    "./src/app/register1/register1.page.ts":
    /*!*********************************************!*\
      !*** ./src/app/register1/register1.page.ts ***!
      \*********************************************/

    /*! exports provided: Register1Page */

    /***/
    function srcAppRegister1Register1PageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Register1Page", function () {
        return Register1Page;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var Register1Page = /*#__PURE__*/function () {
        function Register1Page() {
          _classCallCheck(this, Register1Page);
        }

        _createClass(Register1Page, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return Register1Page;
      }();

      Register1Page.ctorParameters = function () {
        return [];
      };

      Register1Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register1',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./register1.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/register1/register1.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./register1.page.scss */
        "./src/app/register1/register1.page.scss"))["default"]]
      })], Register1Page);
      /***/
    }
  }]);
})();
//# sourceMappingURL=register1-register1-module-es5.js.map