(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-trivia-add-trivia-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/trivias/add-trivia/add-trivia.page.html":
    /*!*****************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/trivias/add-trivia/add-trivia.page.html ***!
      \*****************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppAdminTriviasAddTriviaAddTriviaPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/admin/trivias\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>New Trivia</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Content</ion-label>\n        <ion-input type=\"text\" ngModel name=\"content\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Source</ion-label>\n        <ion-input type=\"text\" ngModel name=\"source\"></ion-input>\n      </ion-item>\n    </ion-list>\n    <ion-button type=\"submit\" color=\"primary\" expand=\"block\">Save</ion-button>\n  </form>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/admin/trivias/add-trivia/add-trivia-routing.module.ts":
    /*!***********************************************************************!*\
      !*** ./src/app/admin/trivias/add-trivia/add-trivia-routing.module.ts ***!
      \***********************************************************************/

    /*! exports provided: AddTriviaPageRoutingModule */

    /***/
    function srcAppAdminTriviasAddTriviaAddTriviaRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddTriviaPageRoutingModule", function () {
        return AddTriviaPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _add_trivia_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./add-trivia.page */
      "./src/app/admin/trivias/add-trivia/add-trivia.page.ts");

      var routes = [{
        path: '',
        component: _add_trivia_page__WEBPACK_IMPORTED_MODULE_3__["AddTriviaPage"]
      }];

      var AddTriviaPageRoutingModule = function AddTriviaPageRoutingModule() {
        _classCallCheck(this, AddTriviaPageRoutingModule);
      };

      AddTriviaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AddTriviaPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/admin/trivias/add-trivia/add-trivia.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/admin/trivias/add-trivia/add-trivia.module.ts ***!
      \***************************************************************/

    /*! exports provided: AddTriviaPageModule */

    /***/
    function srcAppAdminTriviasAddTriviaAddTriviaModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddTriviaPageModule", function () {
        return AddTriviaPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _add_trivia_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./add-trivia-routing.module */
      "./src/app/admin/trivias/add-trivia/add-trivia-routing.module.ts");
      /* harmony import */


      var _add_trivia_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./add-trivia.page */
      "./src/app/admin/trivias/add-trivia/add-trivia.page.ts");

      var AddTriviaPageModule = function AddTriviaPageModule() {
        _classCallCheck(this, AddTriviaPageModule);
      };

      AddTriviaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _add_trivia_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddTriviaPageRoutingModule"]],
        declarations: [_add_trivia_page__WEBPACK_IMPORTED_MODULE_6__["AddTriviaPage"]]
      })], AddTriviaPageModule);
      /***/
    },

    /***/
    "./src/app/admin/trivias/add-trivia/add-trivia.page.scss":
    /*!***************************************************************!*\
      !*** ./src/app/admin/trivias/add-trivia/add-trivia.page.scss ***!
      \***************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppAdminTriviasAddTriviaAddTriviaPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3RyaXZpYXMvYWRkLXRyaXZpYS9hZGQtdHJpdmlhLnBhZ2Uuc2NzcyJ9 */";
      /***/
    },

    /***/
    "./src/app/admin/trivias/add-trivia/add-trivia.page.ts":
    /*!*************************************************************!*\
      !*** ./src/app/admin/trivias/add-trivia/add-trivia.page.ts ***!
      \*************************************************************/

    /*! exports provided: AddTriviaPage */

    /***/
    function srcAppAdminTriviasAddTriviaAddTriviaPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddTriviaPage", function () {
        return AddTriviaPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var src_app_services_trivia_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/services/trivia.service */
      "./src/app/services/trivia.service.ts");

      var AddTriviaPage = /*#__PURE__*/function () {
        function AddTriviaPage(router, triviaService) {
          _classCallCheck(this, AddTriviaPage);

          this.router = router;
          this.triviaService = triviaService;
        }

        _createClass(AddTriviaPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "onSubmit",
          value: function onSubmit(form) {
            var _this = this;

            console.log('Form: ', form);
            this.triviaService.addTrivia(form.value).then(function (res) {
              console.log('Result: ', res);

              _this.router.navigateByUrl('/admin/trivias');
            })["catch"](function (error) {
              return console.log('Error: ', error);
            });
            form.reset();
            this.router.navigateByUrl('/admin/trivias');
          }
        }]);

        return AddTriviaPage;
      }();

      AddTriviaPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: src_app_services_trivia_service__WEBPACK_IMPORTED_MODULE_3__["TriviaService"]
        }];
      };

      AddTriviaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-trivia',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./add-trivia.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/trivias/add-trivia/add-trivia.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./add-trivia.page.scss */
        "./src/app/admin/trivias/add-trivia/add-trivia.page.scss"))["default"]]
      })], AddTriviaPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=add-trivia-add-trivia-module-es5.js.map