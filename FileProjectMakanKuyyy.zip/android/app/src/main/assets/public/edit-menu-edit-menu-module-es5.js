(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-menu-edit-menu-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.html":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.html ***!
      \******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppAdminRestaurantsEditRestoEditMenuEditMenuPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Edit Menu</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form #f=\"ngForm\" (ngSubmit)=\"onSubmit(f)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Name</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_name\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Description</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_desc\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Price</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_price\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Image URL</ion-label>\n        <ion-input type=\"text\" ngModel name=\"menu_image\"></ion-input>\n      </ion-item>\n      <ion-button type=\"submit\" expand=\"block\">Save</ion-button>\n    </ion-list>\n  </form>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu-routing.module.ts":
    /*!************************************************************************************!*\
      !*** ./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu-routing.module.ts ***!
      \************************************************************************************/

    /*! exports provided: EditMenuPageRoutingModule */

    /***/
    function srcAppAdminRestaurantsEditRestoEditMenuEditMenuRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditMenuPageRoutingModule", function () {
        return EditMenuPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _edit_menu_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./edit-menu.page */
      "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.ts");

      var routes = [{
        path: '',
        component: _edit_menu_page__WEBPACK_IMPORTED_MODULE_3__["EditMenuPage"]
      }];

      var EditMenuPageRoutingModule = function EditMenuPageRoutingModule() {
        _classCallCheck(this, EditMenuPageRoutingModule);
      };

      EditMenuPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EditMenuPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.module.ts":
    /*!****************************************************************************!*\
      !*** ./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.module.ts ***!
      \****************************************************************************/

    /*! exports provided: EditMenuPageModule */

    /***/
    function srcAppAdminRestaurantsEditRestoEditMenuEditMenuModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditMenuPageModule", function () {
        return EditMenuPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _edit_menu_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./edit-menu-routing.module */
      "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu-routing.module.ts");
      /* harmony import */


      var _edit_menu_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./edit-menu.page */
      "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.ts");

      var EditMenuPageModule = function EditMenuPageModule() {
        _classCallCheck(this, EditMenuPageModule);
      };

      EditMenuPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _edit_menu_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditMenuPageRoutingModule"]],
        declarations: [_edit_menu_page__WEBPACK_IMPORTED_MODULE_6__["EditMenuPage"]]
      })], EditMenuPageModule);
      /***/
    },

    /***/
    "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.scss":
    /*!****************************************************************************!*\
      !*** ./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.scss ***!
      \****************************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppAdminRestaurantsEditRestoEditMenuEditMenuPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkbWluL3Jlc3RhdXJhbnRzL2VkaXQtcmVzdG8vZWRpdC1tZW51L2VkaXQtbWVudS5wYWdlLnNjc3MifQ== */";
      /***/
    },

    /***/
    "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.ts":
    /*!**************************************************************************!*\
      !*** ./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.ts ***!
      \**************************************************************************/

    /*! exports provided: EditMenuPage */

    /***/
    function srcAppAdminRestaurantsEditRestoEditMenuEditMenuPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditMenuPage", function () {
        return EditMenuPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var src_app_services_restaurant_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/services/restaurant.service */
      "./src/app/services/restaurant.service.ts");
      /* harmony import */


      var src_app_services_menus_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/services/menus.service */
      "./src/app/services/menus.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/fire/database */
      "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-database.js");

      var EditMenuPage = /*#__PURE__*/function () {
        function EditMenuPage(activatedRoute, restoService, menuService, router, db) {
          _classCallCheck(this, EditMenuPage);

          this.activatedRoute = activatedRoute;
          this.restoService = restoService;
          this.menuService = menuService;
          this.router = router;
          this.db = db;
        }

        _createClass(EditMenuPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.activatedRoute.paramMap.subscribe(function (paramMap) {
              if (!paramMap.has('key')) {
                return;
              }

              _this.key = paramMap.get('key');

              _this.db.object('/menus/' + _this.key).valueChanges().subscribe(function (data) {
                console.log('data: ', data);
                _this.menu = data;
                console.log('this.menu: ', _this.menu);
              });
            });
            setTimeout(function () {
              _this.f.setValue(_this.menu);
            });
          }
        }, {
          key: "onSubmit",
          value: function onSubmit(form) {
            console.log('Form: ', form);
          }
        }]);

        return EditMenuPage;
      }();

      EditMenuPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }, {
          type: src_app_services_restaurant_service__WEBPACK_IMPORTED_MODULE_2__["RestaurantService"]
        }, {
          type: src_app_services_menus_service__WEBPACK_IMPORTED_MODULE_3__["MenusService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
        }, {
          type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__["AngularFireDatabase"]
        }];
      };

      EditMenuPage.propDecorators = {
        f: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['f', null]
        }]
      };
      EditMenuPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit-menu',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./edit-menu.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./edit-menu.page.scss */
        "./src/app/admin/restaurants/edit-resto/edit-menu/edit-menu.page.scss"))["default"]]
      })], EditMenuPage);
      /***/
    },

    /***/
    "./src/app/services/menus.service.ts":
    /*!*******************************************!*\
      !*** ./src/app/services/menus.service.ts ***!
      \*******************************************/

    /*! exports provided: MenusService */

    /***/
    function srcAppServicesMenusServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MenusService", function () {
        return MenusService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_fire_database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/fire/database */
      "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-database.js");

      var MenusService = /*#__PURE__*/function () {
        function MenusService(db) {
          _classCallCheck(this, MenusService);

          this.db = db;
          this.dbPath = '/menu';
          this.menuRef = null;
          this.menuRef = db.list(this.dbPath); //ambil semua menu
        }

        _createClass(MenusService, [{
          key: "getMenus",
          value: function getMenus() {
            return this.menuRef;
          }
        }]);

        return MenusService;
      }();

      MenusService.ctorParameters = function () {
        return [{
          type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_2__["AngularFireDatabase"]
        }];
      };

      MenusService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], MenusService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=edit-menu-edit-menu-module-es5.js.map